import React from 'react';
import axios from 'axios';
import { Redirect } from 'react-router';
import './App.scss';

const statusEnum = {
  DONE : "Done",
  TODO : "To Do",
  InProgress : "In Progress"
}

export class TodoForm extends React.Component{

  render() {
    return (
      <div>
      </div>
    )
  }
}