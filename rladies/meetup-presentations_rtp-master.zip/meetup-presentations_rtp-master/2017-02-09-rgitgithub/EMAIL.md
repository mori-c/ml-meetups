Our first meetup of 2017 fast approaching.

R / git / GitHub

Thursday, February 9

6:30pm - 8:30pm

The Edge Workshop Room in Bostock Library

https://www.meetup.com/R-Ladies-RTP/events/237341895/

If you have already RSVPed yes, we look forward to seeing you on Thursday. If not, there are still a few seats left.

The agenda is on the event website.

The workshop materials will be posted at this GitHub repo: https://github.com/rladies/rtp_20170209_rgitgithub. Note that the slides there are currently a work in progress, but they will be finalized before the workshop. However please read and complete the following setup instructions:

https://github.com/rladies/rtp_20170209_rgitgithub/blob/master/SETUP.md

If you have any trouble with any of those steps, don't worry, we will have some time during the meetup to help troubleshoot.

Dinner will be provided, thanks to the generous sponsorship of RStudio! Space is provided by Duke Libraries.

Lastly, parking on Duke's campus can be tricky.

The main visitor lot at Duke is at **Bryan Center** (allow 10 minutes for walk), however since this will be a basketball game day at Duke, it might be busy there. Other lots that are not too far from the venue are **Duke Gardens** (allow 10 minutes for walk) and **Research Dr Garage (serving Eye Center)** (allow 15 minutes for walk).

If you need to ask for directions students on campus should be able to direct you in the direction of Bostock Library. The Edge is the name of the first floor of this library where we'll be holding the event.

Looking forward to seeing you all on Thursday!