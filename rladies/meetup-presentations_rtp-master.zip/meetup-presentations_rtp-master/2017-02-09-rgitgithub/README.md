# R / git / GitHub

Materials for the R / git / GitHub R-Ladies RTP meetup. 

Slides can be viewed at [TBA].

Sign up at https://www.meetup.com/R-Ladies-RTP/events/237341895/.

While the materials for the workshop are designed for being used at the in-person 
workshop, all are welcomed to use and reuse them for learning and teaching.

This workshop assumes no background in R but willingness to learn a scripting
language.

Focus of the workshop is data wrangling and manipulation, and not statistical
data analysis.