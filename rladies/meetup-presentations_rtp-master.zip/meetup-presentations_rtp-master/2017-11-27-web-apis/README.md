# 2017-11-27 Web APIs

Three parts:

1. Twitter - Joyce Cahoon
2. Zillow - Stephanie Zimmer
3. Google NGrams - Julia (?)

One folder per part