## README for workshop\_data ##

last updated: 20180719 <br/>
contact: Sheila Saia (ssaia at ncsu dot edu)

You can find the data to participate in this workshop at https://drive.google.com/drive/folders/1dGJhnoX_KVWBXHJqWzSIrCFr29iy916g?usp=sharing.
