# Agenda

- Announcements
	- 2017 Conference list: https://docs.google.com/presentation/d/11aXtrXuK4m_vV6gNvmXNsh1f05z9yzJD1FVTGFSsmjo/edit
	- DataFest
	- Guest speakers for UNC Data Science course
- Lightening talks: 
	- Mara Sedlins 
	- Lucia Gjeltema
	- Amy Finnegan 
	- Becca Krouse  
- Workshop: Frances Tong + Mine Cetinkaya-Rundel