<img src="https://github.com/rladies/starter-kit/blob/master/logo/R-LadiesGlobal_RBG_online_LogoWithText_Horizontal.png" data-canonical-src="https://github.com/rladies/starter-kit/blob/master/logo/R-LadiesGlobal_RBG_online_LogoWithText_Horizontal.png" width="300" height="100" />

# R-Ladies RTP
 
R-Ladies RTP founded in September 2016 by Mine Cetinkaya-Rundel
  
Co-organizer Elaine McVey
  
Send us an e-mail at *mine@rladies.org* or *elaine@rladies.org* for further information!
  
## 2017

[2017-11-27 Web APIs in R](https://github.com/rladies/meetup-presentations_rtp/tree/master/2017-11-27-web-apis)

[2017-10-26 Functional programming with purrr](https://github.com/rladies/meetup-presentations_rtp/tree/master/2017-10-26-purrr)

[2017-09-19 All about tibbles](https://github.com/rladies/meetup-presentations_rtp/tree/master/2017-09-19-tibbles)

[2017-03-09 Interactive visualizations with Shiny](https://github.com/rladies/meetup-presentations_rtp/tree/master/2017-03-09-shiny)

[2017-02-09 R / git / GitHub](https://github.com/rladies/meetup-presentations_rtp/tree/master/2017-02-09-rgitgithub)

## 2016

[2016-12-13 R Markdown](https://github.com/rladies/meetup-presentations_rtp/tree/master/2016-12-13-rmarkdown)

[2016-10-15 Data visualization in R with ggplot2](https://github.com/rladies/meetup-presentations_rtp/tree/master/2016-10-15-data-viz-ggplot2)

[2016-09-22 Data manipulation in R with dplyr and tidyr](https://github.com/rladies/meetup-presentations_rtp/tree/master/2016-09-22-data-manipulation)
