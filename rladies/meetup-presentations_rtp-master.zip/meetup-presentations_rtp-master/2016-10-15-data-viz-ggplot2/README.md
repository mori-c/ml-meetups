# Data visualization in R with ggplot2

Materials for the Data manipulation in R with dplyr and tidyr R-Ladies RTP meetup. 

Slides can be viewed at [____].

Sign up at https://www.meetup.com/R-Ladies-RTP/events/233728146/.

While the materials for the workshop are designed for being used at the in-person 
workshop, all are welcomed to use and reuse them for learning and teaching.

This workshop assumes no background in R but willingness to learn a scripting
language.

Focus of the workshop is data visualization in R with the ggplot2 package, and 
not statistical data analysis.

All R-Ladies events are intended for women as leaders, mentors, members, and attendees. 
We are emphatically queer and trans friendly. Men are welcomed to attend as guests.